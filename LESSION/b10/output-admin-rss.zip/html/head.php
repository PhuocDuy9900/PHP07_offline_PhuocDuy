<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />

<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700&display=swap" rel="stylesheet" type="text/css" />
<!-- Stylesheets -->
<link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" type="text/css" />
<link rel="stylesheet" href="css/dark.css" type="text/css" />

<link rel="stylesheet" href="css/font-icons.css" type="text/css" />
<link rel="stylesheet" href="css/et-line.css" type="text/css" />
<link rel="stylesheet" href="css/animate.css" type="text/css" />
<link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
<link rel="stylesheet" href="css/tagify.css" type="text/css" />

<!-- Modern Blog Demo Specific Stylesheet -->
<link rel="stylesheet" href="css/modern-blog.css" type="text/css" />
<link rel="stylesheet" href="css/fonts.css" type="text/css" />

<link rel="stylesheet" href="css/custom.css" type="text/css" />
<!-- Document Title -->
<title>News | ZendVN</title>