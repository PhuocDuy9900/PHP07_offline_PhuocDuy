var input = document.querySelector('textarea');
var tagify = new Tagify(input, {
        delimiters: null,

})