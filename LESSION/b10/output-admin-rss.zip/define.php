<?php
define('DIR_DATA', 'data/');
?>